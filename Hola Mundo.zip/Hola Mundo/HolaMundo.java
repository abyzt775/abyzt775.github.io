public class HolaMundo {
    
    public static void main(String[] args) {

        // Escribe el texto en terminal y hace un salto de linea
        System.out.println("Hola Mundo\n");

    }

}
